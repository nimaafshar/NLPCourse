Persian Stop Words List (لیست کلمات ایست فارسی)
----------------------------------------------

# Lists

- for Topic Modeling -> [persian](persian)
- Verbal Stop Words -> [verbal](verbal)
- Non-Verbal Stop Words -> [nonverbal](nonverbal)
- Special Chars -> [chars](chars)
- Short list ([source](http://www.ranks.nl/stopwords/persian)) -> [short](short)
